from http.client import HTTPResponse
import imp
from django.shortcuts import render,redirect
from django.views import View
from contactapp.forms.usercreationform import userRegistration
from contactapp.models import Post
from django.contrib.auth import authenticate,login

class Home(View):
    def get(self,request):
        return render(request,'contactapp/index.html')


class create_user(View):
    def get(self,request):
        form= userRegistration()
        return render(request,"contactapp/signup.html",context={'form':form})
    def post(self,request):
        form = userRegistration(request.POST)
        text = request.POST.get('textdata')
        # print(form)
        if form.is_valid():
            user = form.save()
            if user:
                postuser = Post(user=user ,text_content=text)
                postuser.save()
                if postuser:
                    login(request,user)
                    return redirect('index')
        return render(request,"contactapp/signup.html",context={'form':form,'text':text})



