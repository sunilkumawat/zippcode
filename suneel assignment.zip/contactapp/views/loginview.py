
from django.shortcuts import redirect, render
from django.views import View
from contactapp.forms import  LoginForm
from django.contrib.auth import authenticate,login



class signin(View):
    def get(self,request):
        form =LoginForm()
        return render(request,"contactapp/signin.html",context={'form':form})

    def post(self,request):
        form = LoginForm(request=request,data = request.POST)
        if form.is_valid():
            return redirect('index')
        form =LoginForm()
        return render(request,"contactapp/signin.html",context={'form':form})