from django.urls import path
from .views import Home , create_user,signout,signin

urlpatterns = [
    path('',Home.as_view(),name='index'),
    path('register',create_user.as_view(),name='create_user'),
    path('signout',signout,name='signout'),
    path('signin',signin.as_view(),name='signin'),

]