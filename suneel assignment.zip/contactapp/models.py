import imp
from pyexpat import model
from statistics import mode
from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
# Create your models here.

class Post(models.Model):
    user = models.ForeignKey(User,null=False,on_delete=models.CASCADE)
    text_content = RichTextField()
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.user.username