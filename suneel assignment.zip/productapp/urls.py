from django.urls import path
from .views import create,show , edit,delete

urlpatterns = [
    path('create',create.as_view(),name='create_product'),
    path('show',show,name='product' ),
    path('edit',edit.as_view(),name='edit' ),
    path('delete',delete,name='delete' ),


]