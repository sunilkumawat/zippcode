
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
# Create your views here.
from django.contrib import messages
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse , HttpResponse 
from .models import Product
import json
class create(View):
    def get(self,request):
        if request.user.is_authenticated:
            return render(request,'productapp/createProduct.html')
        else:
            messages.success(request, 'Permission denied.')
            return redirect('signin')
  


    def post(self,request):
        if request.user.is_authenticated:
            key = dict(request.POST.items())
            product_name=key['product_name']
            weight=key['weight']
            price=key['price']
            product = None
            product = Product.objects.create(product_name=product_name,weight=weight,price=price)
            print(product)
            if product is not None:
                return JsonResponse({'status':"product stored successfully"})
                # return render_to_response('productapp/createProduct.html','data stored successfully')
            else:
                # return render_to_response('productapp/createProduct.html',{'status':"product stored failed"})
                return JsonResponse({'status':"product stored failed"})

        messages.success(request, 'Permission denied.')
        return redirect('signin')


@login_required(login_url='signin')
def show(request):
    if request.user.is_authenticated:
        all_product = None
        try:
            all_product = Product.objects.all()
        except Product.DoesNotExist:
            pass
        if all_product is not None:
            context = {
                    'all_product':all_product
                } 
            return render(request,'productapp/showproduct.html',context=context)



class edit(View):
    def get(self,request):
        if request.user.is_authenticated:
            id = request.GET.get('productId')
            print(id)
            pro=None
            try:
                pro= Product.objects.get(id=id)
            except Product.DoesNotExist:
                return None
            print(pro)
            if pro is not None:
                context = {
                    'product':pro
                }
                return render(request,'productapp/update.html',context=context)
            elif pro is None:
                messages.success(request, 'Permission denied.')
                return redirect('product')
        else:
            return render('signin')
        
    def post(self,request):
        id= request.POST.get('product_id')
        name= request.POST.get('product_name')
        weight= request.POST.get('weight')
        price= request.POST.get('price')
        updateProduct = Product.getupdatedById(id,name,weight,price)
        if updateProduct is True:
            messages.success(request, 'product updated successfully.')    
            return redirect('product')
        else:
            messages.success(request, 'product updated failed.')
            return redirect('product')



        


@login_required(login_url='signin')
def delete(request):
    if request.method=='POST':
        id= request.POST.get('productId')
        try:
            product = Product.objects.get(id=id)
        except Product.DoesNotExist:
            pass
        if product is not None:
            product.delete()
            messages.success(request, 'Product is deleted.')
            return redirect('product')
        else:
            messages.success(request, 'Product not deleted.')
            return redirect('product')
    else:
        messages.success(request, 'Permission denied.')
        return redirect('product')

