from django.contrib import admin

# Register your models here.
from productapp.models import Product

@admin.register(Product)
class ProductModel(admin.ModelAdmin):
    list_display = ['product_name','weight','price','created_at','updated_at']