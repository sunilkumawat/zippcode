from itertools import product
from django.db import models

# Create your models here.


class Product(models.Model):
    product_name = models.CharField(max_length=50,null=False)
    weight  = models.FloatField(default=0.0, null=False)
    price = models.FloatField(default=0.0, null=False)
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.product_name

    @staticmethod
    def getupdatedById(id,name,weight,price):
        product=None
        try:
            product = Product.objects.filter(id=id).first()
        except Product.DoesNotExist:
            pass
        if product is not None:
            product.product_name=name
            product.weight=weight
            product.price=price
            product.save()
            return True
        else:
            return False





